@extends('layouts.master')
@section('title', 'FilmesFavoritos')

@section('content')
    <div>
        <favorite-movie>
    </div>
@endsection
