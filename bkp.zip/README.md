<p align="center"><img src="https://media3.giphy.com/media/sJ1YZPymqTzvOe9vzY/giphy.gif" width="400" alt="Laravel Logo"></p>
<p align="center">
<h1>
    FERREIRA FILMES
</h1>
</p>


## About Project :: Sobre o Projeto

### pt-BR

Este projeto nasceu de forma totalmente estudantil, onde estava precisando colocar meus conhecimentos de [VUE3](https://vuejs.org/) e [LARAVEL](https://laravel.com/docs/) em pratica. Tem sido uma enorme satisfação trabalhar neste projeto pessoal e disponibilizar para todos.


### en

This project was born entirely as a student, where I needed to put my knowledge of [VUE3](https://vuejs.org/) and [LARAVEL](https://laravel.com/docs/) into practice. It has been a great pleasure to work on this personal project and make it available to everyone.

---
## 
